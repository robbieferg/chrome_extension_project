package com.codeclan.example.flickbait;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlickBaitApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlickBaitApplication.class, args);
	}

}
