package com.codeclan.example.flickbait;

import com.codeclan.example.flickbait.models.*;
import org.junit.jupiter.api.BeforeAll;

import com.codeclan.example.flickbait.repositories.WebPageRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;

@SpringBootTest
public class FlickBaitApplicationTests {




	@Test
	void contextLoads() {
	}



}
